public class Board {
    private Square[][] board;
    private Camp[] camp;

    private int choose_x;
    private int choose_y;

    public Board(Square[][] board, Camp[] camp) {
        this.board = board;
        this.camp = camp;

        camp[1] = new Camp(Color.WHITE, new Square[6][6]);
        camp[1].createCamp1();
        camp[1].setupCamp();

        camp[2] = new Camp(Color.BLACK, new Square[6][6]);
        camp[2].createCamp2();
        camp[2].setupCamp();

        createBoard();
        setupBoard();
    }

    public void createBoard() {
        for (int i = 1; i <= 16; ++i) for (int j = 1; j <= 16; ++j) board[i][j] = new Square(new Position(i, j), null);
    }

    public void setupBoard() {
        for (int i = 1; i <= 5; ++i) {
            switch (i) {
                case 1, 2:
                    for (int j = 1; j <= 5; ++j) board[i][j].setPiece(new Piece(camp[1].getColor()));
                    break;
                default:
                    for (int j = 1; j <= (5 - i) + 2; ++j) board[i][j].setPiece(new Piece(camp[1].getColor()));
            }
        }

        for (int i = 16; i >= 12; --i) {
            switch (i) {
                case 15, 16:
                    for (int j = 12; j <= 16; ++j) board[i][j].setPiece(new Piece(camp[2].getColor()));
                    break;
                default:
                    for (int j = (16 - i) + 11; j <= 16; ++j) board[i][j].setPiece(new Piece(camp[2].getColor()));
            }
        }
    }

    public Camp getCamp1() {
        return camp[1];
    }

    public Camp getCamp2() {
        return camp[2];
    }

    public boolean isEmpty(Piece piece) {
        return piece == null;
    }

    public void showAllPossiblePosition(int x, int y) {
        StringBuilder concat = new StringBuilder();

        if (x + 1 >= 1 && x + 1 <= 16 && y >= 1 && y <= 16) {
            this.setwhichSquare(x + 1, y);
            if (isEmpty(this.getSquare().getPiece())) concat.append(String.format("(%d, %d) ", choose_x, choose_y));
            else {
                concat.append("End ");
                System.out.println(concat);
            }
            this.setwhichSquare(choose_x - 1, choose_y);
        }

        if (x - 1 >= 1 && x - 1 <= 16 && y >= 1 && y <= 16) {
            this.setwhichSquare(x - 1, y);
            if (isEmpty(this.getSquare().getPiece())) concat.append(String.format("(%d, %d) ", choose_x, choose_y));
            else {
                concat.append("End ");
                System.out.println(concat);
            }
            this.setwhichSquare(choose_x + 1, choose_y);
        }

        if (x >= 1 && x <= 16 && y + 1 >= 1 && y + 1 <= 16) {
            this.setwhichSquare(x, y + 1);
            if (isEmpty(this.getSquare().getPiece())) concat.append(String.format("(%d, %d) ", choose_x, choose_y));
            else {
                concat.append("End ");
                System.out.println(concat);
            }
            this.setwhichSquare(choose_x, choose_y - 1);
        }

        if (x >= 1 && x <= 16 && y - 1 >= 1 && y - 1 <= 16) {
            this.setwhichSquare(x, y - 1);
            if (isEmpty(this.getSquare().getPiece())) concat.append(String.format("(%d, %d) ", choose_x, choose_y));
            else {
                concat.append("End ");
                System.out.println(concat);
            }
            this.setwhichSquare(choose_x, choose_y + 1);
        }

        if (x + 1 >= 1 && x + 1 <= 16 && y + 1 >= 1 && y + 1 <= 16) {
            this.setwhichSquare(x + 1, y + 1);
            if (isEmpty(this.getSquare().getPiece())) {
                concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                this.setwhichSquare(choose_x - 1, choose_y - 1);
            } else checkPossibleLadder(concat, choose_x, choose_y, x, y, 1);
        }

        if (x - 1 >= 1 && x - 1 <= 16 && y - 1 >= 1 && y - 1 <= 16) {
            this.setwhichSquare(x - 1, y - 1);
            if (isEmpty(this.getSquare().getPiece())) {
                concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                this.setwhichSquare(choose_x + 1, choose_y + 1);
            } else checkPossibleLadder(concat, choose_x, choose_y, x, y, 2);
        }

        if (x + 1 >= 1 && x + 1 <= 16 && y - 1 >= 1 && y - 1 <= 16) {
            this.setwhichSquare(x + 1, y - 1);
            if (isEmpty(this.getSquare().getPiece())) {
                concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                this.setwhichSquare(choose_x - 1, choose_y + 1);
            } else checkPossibleLadder(concat, choose_x, choose_y, x, y, 3);
        }

        if (x - 1 >= 1 && x - 1 <= 16 && y + 1 >= 1 && y + 1 <= 16) {
            this.setwhichSquare(x - 1, y + 1);
            if (isEmpty(this.getSquare().getPiece())) {
                concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                this.setwhichSquare(choose_x + 1, choose_y - 1);
            } else checkPossibleLadder(concat, choose_x, choose_y, x, y, 4);
        }
    }

    public void checkPossibleLadder(StringBuilder concat, int x, int y, int initial_x, int initial_y, int type) {

    }

    public void setwhichSquare(int choose_x, int choose_y) {
        this.choose_x = choose_x;
        this.choose_y = choose_y;
    }

    public Square getSquare() {
        return this.board[this.choose_x][this.choose_y];
    }
}
