import java.util.Objects;

public class GameSession {
    private Player[] player;
    private Board board;
    private int time;
    private int choose;

    public GameSession(Player[] player, Board board, int time) {
        this.player = player;
        this.board = board;
        this.time = time;

        this.setwhichPlayer(1);
        this.getwhichPlayer().setBoard(board);

        this.setwhichPlayer(2);
        this.getwhichPlayer().setBoard(board);
    }

    public void setwhichPlayer(int y) {
        this.choose = y;
    }

    public Player getwhichPlayer() {
        return this.player[this.choose];
    }

    public void checkWin(Player player) {
        int countSatisfiedCondition = 0;

        if (Objects.equals(player, this.player[1])) {
            for (int i = 1; i <= 5; ++i) {
                for (int j = 1; j <= 5; ++j) {
                    player.getBoard().getCamp1().setwhichSquare(i, j);

                    if (player.getBoard().getCamp1().getSquare() != null) if (player.getBoard().getCamp1().getSquare().getPosition().getX() + player.getBoard().getCamp1().getSquare().getPosition().getY() <= 7) if (player.getBoard().getCamp1().getSquare().getPiece() != null) if (player.getBoard().getCamp1().getSquare().getPiece().getColor() == Color.BLACK) countSatisfiedCondition++;
                }
            }
        } else {
            for (int i = 1; i <= 5; ++i) {
                for (int j = 1; j <= 5; ++j) {
                    player.getBoard().getCamp2().setwhichSquare(i, j);

                    if (player.getBoard().getCamp2().getSquare() != null) if (player.getBoard().getCamp2().getSquare().getPosition().getX() + player.getBoard().getCamp2().getSquare().getPosition().getY() >= 27) if (player.getBoard().getCamp2().getSquare().getPiece() != null) if (player.getBoard().getCamp2().getSquare().getPiece().getColor() == Color.WHITE) countSatisfiedCondition++;
                }
            }
        }

        if (countSatisfiedCondition == 19) announceWinner(player);
    }

    public void announceWinner(Player player) {
        System.out.println("The winner is " + player.getUsername() + "with ID: " + player.getPlayerID());
    }
}
