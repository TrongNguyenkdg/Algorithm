public class Camp {
    private Square[][] area;
    private Color color;

    private int choose_x;
    private int choose_y;

    public Camp(Color color, Square[][] area) {
        this.color = color;
        this.area = area;
    }

    public Color getColor() {
        return this.color;
    }

    public void createCamp1() {
        for (int i = 1; i <= 5; ++i) {
            switch (i) {
                case 1, 2:
                    for (int j = 1; j <= 5; ++j) area[i][j] = new Square(new Position(i, j), null);
                    break;
                default:
                    for (int j = 1; j <= (5 - i) + 2; ++j) if (i + j <= 7) area[i][j] = new Square(new Position(i, j), null);
            }
        }
    }

    public void createCamp2() {
        for (int i = 16; i >= 12; --i) {
            switch (i) {
                case 15, 16:
                    for (int j = 16; j >= 12; --j) area[i - 11][j - 11] = new Square(new Position(i, j), null);
                    break;
                default:
                    for (int j = (i - 16) + 17; j >= 12; --j) if (i + j >= 27) area[i - 11][j - 11] = new Square(new Position(i, j), null);
            }
        }
    }

    public void setupCamp() {
        for (int i = 1; i <= 5; ++i) for (int j = 1; j <= 5; ++j) if (area[i][j] != null) area[i][j].setPiece(new Piece(this.getColor()));
    }

    public void setwhichSquare(int choose_x, int choose_y) {
        this.choose_x = choose_x;
        this.choose_y = choose_y;
    }

    public Square getSquare() {
        return this.area[this.choose_x][this.choose_y];
    }
}
