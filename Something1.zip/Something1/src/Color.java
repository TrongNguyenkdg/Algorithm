public enum Color {
    BLACK, WHITE;
}
