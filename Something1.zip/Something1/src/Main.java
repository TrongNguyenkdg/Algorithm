import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Please enter your name");
        String name = sc.nextLine();

        Player player = new Player(name, 1, null);

        System.out.println("Please enter your other name");
        String otherName = sc.nextLine();

        Player player2 = new Player(otherName, 2, null);

        Player[] players = new Player[3];
        players[1] = player;
        players[2] = player2;

        GameSession gameSession = new GameSession(players, new Board(new Square[17][17], new Camp[3]), 2);

        gameSession.setwhichPlayer(1);
        gameSession.getwhichPlayer().getBoard().showAllPossiblePosition(2, 4);

        gameSession.getwhichPlayer().move1(new Position(2, 4), new Position(3, 5));
        gameSession.checkWin(players[1]);

        gameSession.setwhichPlayer(2);
        gameSession.getwhichPlayer().getBoard().showAllPossiblePosition(14, 13);

        gameSession.getwhichPlayer().move2(new Position(14, 13), new Position(13, 13));
        gameSession.checkWin(players[2]);
    }
}