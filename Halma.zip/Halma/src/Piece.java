public class Piece {
    private Color color;

    // this String variable is created for clear explicit demonstration of a Piece
    private String representation = "O";

    public Piece(Color color) {
        this.color = color;
    }

    public Color getColor() {
        return color;
    }

    // this method is created for clear explicit demonstration of a Piece
    public String getRepresentation() {
        return representation;
    }

    @Override
    public String toString() {
        return String.format("%s %s ", (getColor() == Color.BLACK ? "\u001B[40m\u001B[37m" : "\u001B[47m\u001B[30m"), getRepresentation());
    }
}
