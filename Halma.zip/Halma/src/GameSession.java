import java.util.Iterator;
import java.util.Objects;
import java.util.Scanner;

public class GameSession {
    private Player[] player;
    private Board board;
    private int time;
    private int choose;

    public GameSession(Player[] player, Board board, int time) {
        this.player = player;
        this.board = board;
        this.time = time;

        this.setwhichPlayer(1);
        this.getwhichPlayer().setBoard(board);

        this.setwhichPlayer(2);
        this.getwhichPlayer().setBoard(board);
    }

    public void setwhichPlayer(int y) {
        this.choose = y;
    }

    public Player getwhichPlayer() {
        return this.player[this.choose];
    }

    // this method is created for clear explicit demonstration of a Board
    public void showBoard() {
        for (int i = 1; i <= 16; ++i) {
            for (int j = 1; j <= 16; ++j) {
                this.getwhichPlayer().getBoard().setwhichSquare(i, j);
                System.out.print(this.getwhichPlayer().getBoard().getSquare().getPiece() != null ? "\u001B[0m" + this.getwhichPlayer().getBoard().getSquare().getPiece() + "\u001B[0m" : "\u001B[0m\u001B[43m\u001B[36m * \u001B[0m");
            }
            System.out.println();
        }
    }

    public void startGame() {
        Scanner scanner = new Scanner(System.in);

        int x1; int y1; int x2; int y2; int turn = 1;
        boolean loop1 = true; boolean loop2;
        String confirm;

        while (loop1) {
            loop2 = true;

            this.setwhichPlayer(turn % 2 == 0 ? 2 : 1);

            while (loop2) {
                try {
                    System.out.print("Please select your piece at position x: ");
                    x1 = scanner.nextInt();
                    System.out.print("And at position y: ");
                    y1 = scanner.nextInt();

                    if (x1 >= 1 && x1 <= 16 && y1 >= 1 && y1 <= 16) {
                        this.getwhichPlayer().getBoard().setwhichSquare(x1, y1);
                        if (this.getwhichPlayer().getBoard().getSquare().getPiece() != null) {
                            if (!this.getwhichPlayer().getBoard().showAllPossiblePosition(x1, y1).isEmpty())
                                System.out.println(this.getwhichPlayer().getBoard().showAllPossiblePosition(x1, y1));
                            else throw new Exception();
                        } else throw new Exception();
                    } else throw new Exception();

                    System.out.println("Do you want to move this piece ? [Yes/No] ");
                    confirm = scanner.next();

                    if (confirm.equalsIgnoreCase("Yes")) {
                        System.out.print("You may now move this piece to position x: ");
                        x2 = scanner.nextInt();
                        System.out.print("And position y: ");
                        y2 = scanner.nextInt();

                        if (x2 >= 1 && x2 <= 16 && y2 >= 1 && y2 <= 16) {
                            if (this.getwhichPlayer().getBoard().showAllPossiblePosition(x1, y1).indexOf(String.format("(%d, %d)", x2, y2)) != -1) {
                                if (Objects.equals(this.getwhichPlayer(), player[1])) this.getwhichPlayer().move1(new Position(x1, y1), new Position(x2, y2));
                                else this.getwhichPlayer().move2(new Position(x1, y1), new Position(x2, y2));
                            } else throw new Exception();
                        } else throw new Exception();

                        loop2 = false;
                        loop1 = !this.checkWin(getwhichPlayer());
                    } else if (!confirm.equalsIgnoreCase("No")) throw new Exception();
                } catch (Exception e) {
                    System.out.println("Invalid input");
                }
            }

            this.showBoard();

            if (!loop1) endGame();

            ++turn;
        }
    }

    //this method is created to announce the winner
    public void endGame() {
        System.out.println("The player with username " + this.getwhichPlayer().getUsername() + " and ID " + this.getwhichPlayer().getPlayerID() + " has won the game");
    }

    public boolean checkWin(Player player) {
        int countSatisfiedCondition = 0;

        if (Objects.equals(player, this.player[1])) {
            for (int i = 1; i <= 5; ++i) {
                for (int j = 1; j <= 5; ++j) {
                    player.getBoard().getCamp1().setwhichSquare(i, j);

                    if (player.getBoard().getCamp1().getSquare() != null) if (player.getBoard().getCamp1().getSquare().getPosition().getX() + player.getBoard().getCamp1().getSquare().getPosition().getY() <= 7) if (player.getBoard().getCamp1().getSquare().getPiece() != null) if (player.getBoard().getCamp1().getSquare().getPiece().getColor() == Color.BLACK) countSatisfiedCondition++;
                }
            }
        } else {
            for (int i = 1; i <= 5; ++i) {
                for (int j = 1; j <= 5; ++j) {
                    player.getBoard().getCamp2().setwhichSquare(i, j);

                    if (player.getBoard().getCamp2().getSquare() != null) if (player.getBoard().getCamp2().getSquare().getPosition().getX() + player.getBoard().getCamp2().getSquare().getPosition().getY() >= 27) if (player.getBoard().getCamp2().getSquare().getPiece() != null) if (player.getBoard().getCamp2().getSquare().getPiece().getColor() == Color.WHITE) countSatisfiedCondition++;
                }
            }
        }

        return countSatisfiedCondition == 19;
    }
}
