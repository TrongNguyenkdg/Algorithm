public class Board {
    private Square[][] board;
    private Camp[] camp;

    private int choose_x;
    private int choose_y;

    public Board(Square[][] board, Camp[] camp) {
        this.board = board;
        this.camp = camp;

        camp[1] = new Camp(Color.WHITE, new Square[6][6]);
        camp[1].createCamp1();
        camp[1].setupCamp();

        camp[2] = new Camp(Color.BLACK, new Square[6][6]);
        camp[2].createCamp2();
        camp[2].setupCamp();

        createBoard();
        setupBoard();
    }

    public void createBoard() {
        for (int i = 1; i <= 16; ++i) for (int j = 1; j <= 16; ++j) board[i][j] = new Square(new Position(i, j), null);
    }

    public void setupBoard() {
        for (int i = 1; i <= 5; ++i) {
            switch (i) {
                case 1, 2:
                    for (int j = 1; j <= 5; ++j) board[i][j].setPiece(new Piece(camp[1].getColor()));
                    break;
                default:
                    for (int j = 1; j <= (5 - i) + 2; ++j) board[i][j].setPiece(new Piece(camp[1].getColor()));
            }
        }

        for (int i = 16; i >= 12; --i) {
            switch (i) {
                case 15, 16:
                    for (int j = 12; j <= 16; ++j) board[i][j].setPiece(new Piece(camp[2].getColor()));
                    break;
                default:
                    for (int j = (16 - i) + 11; j <= 16; ++j) board[i][j].setPiece(new Piece(camp[2].getColor()));
            }
        }
    }

    public Camp getCamp1() {
        return camp[1];
    }

    public Camp getCamp2() {
        return camp[2];
    }

    public boolean isEmpty(Piece piece) {
        return piece == null;
    }

    public StringBuilder showAllPossiblePosition(int x, int y) {
        StringBuilder concat = new StringBuilder();

        if (x + 1 >= 1 && x + 1 <= 16 && y + 1 >= 1 && y + 1 <= 16) {
            this.setwhichSquare(x + 1, y + 1);
            if (isEmpty(this.getSquare().getPiece())) concat.append(String.format("(%d, %d) ", choose_x, choose_y));
            else {
                if (x + 2 >= 1 && x + 2 <= 16 && y + 2 >= 1 && y + 2 <= 16) {
                    this.setwhichSquare(choose_x + 1, choose_y + 1);
                    if (isEmpty(this.getSquare().getPiece())) {
                        concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                        checkPossibleLadder(choose_x, choose_y, 9, concat);
                    }
                }
            }
        }

        if (x + 1 >= 1 && x + 1 <= 16 && y >= 1 && y <= 16) {
            this.setwhichSquare(x + 1, y);
            if (isEmpty(this.getSquare().getPiece())) concat.append(String.format("(%d, %d) ", choose_x, choose_y));
            else {
                if (x + 2 >= 1 && x + 2 <= 16 && y >= 1 && y <= 16) {
                    this.setwhichSquare(choose_x + 1, choose_y);
                    if (isEmpty(this.getSquare().getPiece())) {
                        concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                        checkPossibleLadder(choose_x, choose_y, 10, concat);
                    }
                }
            }
        }

        if (x + 1 >= 1 && x + 1 <= 16 && y - 1 >= 1 && y - 1 <= 16) {
            this.setwhichSquare(x + 1, y - 1);
            if (isEmpty(this.getSquare().getPiece())) concat.append(String.format("(%d, %d) ", choose_x, choose_y));
            else {
                if (x + 2 >= 1 && x + 2 <= 16 && y - 2 >= 1 && y - 2 <= 16) {
                    this.setwhichSquare(choose_x + 1, choose_y - 1);
                    if (isEmpty(this.getSquare().getPiece())) {
                        concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                        checkPossibleLadder(choose_x, choose_y, 11, concat);
                    }
                }
            }
        }

        if (x >= 1 && x <= 16 && y - 1 >= 1 && y - 1 <= 16) {
            this.setwhichSquare(x, y - 1);
            if (isEmpty(this.getSquare().getPiece())) concat.append(String.format("(%d, %d) ", choose_x, choose_y));
            else {
                if (x >= 1 && x <= 16 && y - 2 >= 1 && y - 2 <= 16) {
                    this.setwhichSquare(choose_x, choose_y - 1);
                    if (isEmpty(this.getSquare().getPiece())) {
                        concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                        checkPossibleLadder(choose_x, choose_y, 12, concat);
                    }
                }
            }
        }

        if (x - 1 >= 1 && x - 1 <= 16 && y - 1 >= 1 && y - 1 <= 16) {
            this.setwhichSquare(x - 1, y - 1);
            if (isEmpty(this.getSquare().getPiece())) concat.append(String.format("(%d, %d) ", choose_x, choose_y));
            else {
                if (x - 2 >= 1 && x - 2 <= 16 && y - 2 >= 1 && y - 2 <= 16) {
                    this.setwhichSquare(choose_x - 1, choose_y - 1);
                    if (isEmpty(this.getSquare().getPiece())) {
                        concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                        checkPossibleLadder(choose_x, choose_y, 13, concat);
                    }
                }
            }
        }

        if (x - 1 >= 1 && x - 1 <= 16 && y >= 1 && y <= 16) {
            this.setwhichSquare(x - 1, y);
            if (isEmpty(this.getSquare().getPiece())) concat.append(String.format("(%d, %d) ", choose_x, choose_y));
            else {
                if (x - 2 >= 1 && x - 2 <= 16 && y >= 1 && y <= 16) {
                    this.setwhichSquare(choose_x - 1, choose_y);
                    if (isEmpty(this.getSquare().getPiece())) {
                        concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                        checkPossibleLadder(choose_x, choose_y, 14, concat);
                    }
                }
            }
        }

        if (x - 1 >= 1 && x - 1 <= 16 && y + 1 >= 1 && y + 1 <= 16) {
            this.setwhichSquare(x - 1, y + 1);
            if (isEmpty(this.getSquare().getPiece())) concat.append(String.format("(%d, %d) ", choose_x, choose_y));
            else {
                if (x - 2 >= 1 && x - 2 <= 16 && y + 2 >= 1 && y + 2 <= 16) {
                    this.setwhichSquare(choose_x - 1, choose_y + 1);
                    if (isEmpty(this.getSquare().getPiece())) {
                        concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                        checkPossibleLadder(choose_x, choose_y, 15, concat);
                    }
                }
            }
        }

        if (x >= 1 && x <= 16 && y + 1 >= 1 && y + 1 <= 16) {
            this.setwhichSquare(x, y + 1);
            if (isEmpty(this.getSquare().getPiece())) concat.append(String.format("(%d, %d) ", choose_x, choose_y));
            else {
                if (x >= 1 && x <= 16 && y + 2 >= 1 && y + 2 <= 16) {
                    this.setwhichSquare(choose_x, choose_y + 1);
                    if (isEmpty(this.getSquare().getPiece())) {
                        concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                        checkPossibleLadder(choose_x, choose_y, 16, concat);
                    }
                }
            }
        }

        return concat;
    }

    public void checkPossibleLadder(int x, int y, int type, StringBuilder concat) {
        switch (type) {
            case 1:
                checkImplementation(x, y, new boolean[] {true, false, true, true, true, true, true, true, true}, concat);
                break;
            case 2:
                checkImplementation(x, y, new boolean[] {true, true, false, true, true, true, true, true, true}, concat);
                break;
            case 3:
                checkImplementation(x, y, new boolean[] {true, true, true, false, true, true, true, true, true}, concat);
                break;
            case 4:
                checkImplementation(x, y, new boolean[] {true, true, true, true, false, true, true, true, true}, concat);
                break;
            case 5:
                checkImplementation(x, y, new boolean[] {true, true, true, true, true, false, true, true, true}, concat);
                break;
            case 6:
                checkImplementation(x, y, new boolean[] {true, true, true, true, true, true, false, true, true}, concat);
                break;
            case 7:
                checkImplementation(x, y, new boolean[] {true, true, true, true, true, true, true, false, true}, concat);
                break;
            case 8:
                checkImplementation(x, y, new boolean[] {true, true, true, true, true, true, true, true, false}, concat);
                break;

            case 9:
                checkImplementation(x, y, new boolean[] {false, true, false, false, false, false, false, false, false}, concat);
                break;
            case 10:
                checkImplementation(x, y, new boolean[] {false, false, true, false, false, false, false, false, false}, concat);
                break;
            case 11:
                checkImplementation(x, y, new boolean[] {false, false, false, true, false, false, false, false, false}, concat);
                break;
            case 12:
                checkImplementation(x, y, new boolean[] {false, false, false, false, true, false, false, false, false}, concat);
                break;
            case 13:
                checkImplementation(x, y, new boolean[] {false, false, false, false, false, true, false, false, false}, concat);
                break;
            case 14:
                checkImplementation(x, y, new boolean[] {false, false, false, false, false, false, true, false, false}, concat);
                break;
            case 15:
                checkImplementation(x, y, new boolean[] {false, false, false, false, false, false, false, true, false}, concat);
                break;
            default:
                checkImplementation(x, y, new boolean[] {false, false, false, false, false, false, false, false, true}, concat);
                break;
        }
    }

    public void checkImplementation(int x, int y, boolean[] array, StringBuilder concat) {
        if (array[1]) {
            if (x + 1 >= 1 && x + 1 <= 16 && y + 1 >= 1 && y + 1 <= 16) {
                this.setwhichSquare(x + 1, y + 1);
                if (!isEmpty(this.getSquare().getPiece())) {
                    if (x + 2 >= 1 && x + 2 <= 16 && y + 2 >= 1 && y + 2 <= 16) {
                        this.setwhichSquare(choose_x + 1, choose_y + 1);
                        if (isEmpty(this.getSquare().getPiece())) {
                            concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                            checkPossibleLadder(choose_x, choose_y, 5, concat);
                        }
                    }
                }
            }
        }

        if (array[2]) {
            if (x + 1 >= 1 && x + 1 <= 16 && y >= 1 && y <= 16) {
                this.setwhichSquare(x + 1, y);
                if (!isEmpty(this.getSquare().getPiece())) {
                    if (x + 2 >= 1 && x + 2 <= 16 && y >= 1 && y <= 16) {
                        this.setwhichSquare(choose_x + 1, choose_y);
                        if (isEmpty(this.getSquare().getPiece())) {
                            concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                            checkPossibleLadder(choose_x, choose_y, 6, concat);
                        }
                    }
                }
            }
        }

        if (array[3]) {
            if (x + 1 >= 1 && x + 1 <= 16 && y - 1 >= 1 && y - 1 <= 16) {
                this.setwhichSquare(x + 1, y - 1);
                if (!isEmpty(this.getSquare().getPiece())) {
                    if (x + 2 >= 1 && x + 2 <= 16 && y - 2 >= 1 && y - 2 <= 16) {
                        this.setwhichSquare(choose_x + 1, choose_y - 1);
                        if (isEmpty(this.getSquare().getPiece())) {
                            concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                            checkPossibleLadder(choose_x, choose_y, 7, concat);
                        }
                    }
                }
            }
        }

        if (array[4]) {
            if (x >= 1 && x <= 16 && y - 1 >= 1 && y - 1 <= 16) {
                this.setwhichSquare(x, y - 1);
                if (!isEmpty(this.getSquare().getPiece())) {
                    if (x >= 1 && x <= 16 && y - 2 >= 1 && y - 2 <= 16) {
                        this.setwhichSquare(choose_x, choose_y - 1);
                        if (isEmpty(this.getSquare().getPiece())) {
                            concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                            checkPossibleLadder(choose_x, choose_y, 8, concat);
                        }
                    }
                }
            }
        }

        if (array[5]) {
            if (x - 1 >= 1 && x - 1 <= 16 && y - 1 >= 1 && y - 1 <= 16) {
                this.setwhichSquare(x - 1, y - 1);
                if (!isEmpty(this.getSquare().getPiece())) {
                    if (x - 2 >= 1 && x - 2 <= 16 && y - 2 >= 1 && y - 2 <= 16) {
                        this.setwhichSquare(choose_x - 1, choose_y - 1);
                        if (isEmpty(this.getSquare().getPiece())) {
                            concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                            checkPossibleLadder(choose_x, choose_y, 1, concat);
                        }
                    }
                }
            }
        }

        if (array[6]) {
            if (x - 1 >= 1 && x - 1 <= 16 && y >= 1 && y <= 16) {
                this.setwhichSquare(x - 1, y);
                if (!isEmpty(this.getSquare().getPiece())) {
                    if (x - 2 >= 1 && x - 2 <= 16 && y >= 1 && y <= 16) {
                        this.setwhichSquare(choose_x - 1, choose_y);
                        if (isEmpty(this.getSquare().getPiece())) {
                            concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                            checkPossibleLadder(choose_x, choose_y, 2, concat);
                        }
                    }
                }
            }
        }

        if (array[7]) {
            if (x - 1 >= 1 && x - 1 <= 16 && y + 1 >= 1 && y + 1 <= 16) {
                this.setwhichSquare(x - 1, y + 1);
                if (!isEmpty(this.getSquare().getPiece())) {
                    if (x - 2 >= 1 && x - 2 <= 16 && y + 2 >= 1 && y + 2 <= 16) {
                        this.setwhichSquare(choose_x - 1, choose_y + 1);
                        if (isEmpty(this.getSquare().getPiece())) {
                            concat.append(String.format("(%d, %d) ", choose_x, choose_y));

                            checkPossibleLadder(choose_x, choose_y, 3, concat);
                        }
                    }
                }
            }
        }

        if (array[8]) {
            if (x >= 1 && x <= 16 && y + 1 >= 1 && y + 1 <= 16) {
                this.setwhichSquare(x, y + 1);
                if (!isEmpty(this.getSquare().getPiece())) {
                    if (x >= 1 && x <= 16 && y + 2 >= 1 && y + 2 <= 16) {
                        this.setwhichSquare(choose_x, choose_y + 1);
                        if (isEmpty(this.getSquare().getPiece())) {
                            concat.append(String.format("(%d, %d)  ", choose_x, choose_y));

                            checkPossibleLadder(choose_x, choose_y, 4, concat);
                        }
                    }
                }
            }
        }
    }

    public void setwhichSquare(int choose_x, int choose_y) {
        this.choose_x = choose_x;
        this.choose_y = choose_y;
    }

    public Square getSquare() {
        return this.board[this.choose_x][this.choose_y];
    }
}
