public class Position {
    private int pos_x;
    private int pos_y;

    public Position(int x, int y) {
        this.pos_x = x;
        this.pos_y = y;
    }

    public int getX() {
        return pos_x;
    }

    public int getY() {
        return pos_y;
    }
}
