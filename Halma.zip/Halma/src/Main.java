import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Please enter your name");
        String name = sc.nextLine();

        Player player = new Player(name, 1, null);

        System.out.println("Please enter your other name");
        String otherName = sc.nextLine();

        Player player2 = new Player(otherName, 2, null);

        Player[] players = new Player[3];
        players[1] = player;
        players[2] = player2;

        GameSession gameSession = new GameSession(players, new Board(new Square[17][17], new Camp[3]), 2);
        gameSession.showBoard();
        gameSession.startGame();
    }
}