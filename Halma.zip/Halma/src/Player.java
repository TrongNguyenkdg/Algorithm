public class Player {
    private String username;
    private int PlayerID;
    private Board board;

    public Player(String username, int PlayerID, Board board) {
        this.username = username;
        this.PlayerID = PlayerID;
        this.board = board;
    }

    public void setBoard(Board board) {
        this.board = board;
    }

    public Board getBoard() {
        return board;
    }

    public String getUsername() {
        return username;
    }

    public int getPlayerID() {
        return PlayerID;
    }

    public void move1(Position initialpos, Position newpos) {
        this.getBoard().setwhichSquare(initialpos.getX(), initialpos.getY());
        this.getBoard().getSquare().setPiece(null);

        if (initialpos.getX() <= 5 && initialpos.getY() <= 5) {
            this.getBoard().getCamp1().setwhichSquare(initialpos.getX(), initialpos.getY());

            if (this.getBoard().getCamp1().getSquare().getPosition().getX() + this.getBoard().getCamp1().getSquare().getPosition().getY() <= 7) this.getBoard().getCamp1().getSquare().setPiece(null);
        }

        this.getBoard().setwhichSquare(newpos.getX(), newpos.getY());
        this.getBoard().getSquare().setPiece(new Piece(this.getBoard().getCamp1().getColor()));

        if (newpos.getX() <= 5 && newpos.getY() <= 5) {
            this.getBoard().getCamp1().setwhichSquare(newpos.getX(), newpos.getY());

            if (this.getBoard().getCamp1().getSquare() != null) if (this.getBoard().getCamp1().getSquare().getPosition().getX() + this.getBoard().getCamp1().getSquare().getPosition().getY() <= 7) this.getBoard().getCamp1().getSquare().setPiece(new Piece(this.getBoard().getCamp1().getColor()));
        }
    }

    public void move2(Position initialpos, Position newpos) {
        this.getBoard().setwhichSquare(initialpos.getX(), initialpos.getY());
        this.getBoard().getSquare().setPiece(null);

        if (initialpos.getX() >= 12 && initialpos.getY() >= 12) {
            this.getBoard().getCamp2().setwhichSquare(initialpos.getX() - 11, initialpos.getY() - 11);

            if (this.getBoard().getCamp2().getSquare().getPosition().getX() + this.getBoard().getCamp2().getSquare().getPosition().getY() >= 27) this.getBoard().getCamp2().getSquare().setPiece(null);
        }

        this.getBoard().setwhichSquare(newpos.getX(), newpos.getY());
        this.getBoard().getSquare().setPiece(new Piece(this.getBoard().getCamp2().getColor()));

        if (newpos.getX() >= 12 && newpos.getY() >= 12) {
            this.getBoard().getCamp2().setwhichSquare(newpos.getX() - 11, newpos.getY() - 11);

            if (this.getBoard().getCamp2().getSquare() != null) if (this.getBoard().getCamp2().getSquare().getPosition().getX() + this.getBoard().getCamp2().getSquare().getPosition().getY() >= 27) this.getBoard().getCamp2().getSquare().setPiece(new Piece(this.getBoard().getCamp2().getColor()));
        }
    }
}
